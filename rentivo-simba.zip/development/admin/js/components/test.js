// @TODO This is an example console.log(). Remove for production
console.log( 'testadmin.js' );